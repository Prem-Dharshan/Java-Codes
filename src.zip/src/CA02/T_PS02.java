package CA02;

public class T_PS02 {
    public static void main(String[] args) {

    }
}


class MyThread extends Thread {

    public MyThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        super.run();
    }
}
